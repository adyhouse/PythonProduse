"""
Program Import Produse MobileSentrix → WooCommerce
Versiune: 2.0 - cu GUI și funcționalitate completă
"""

import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox, filedialog
import os
import sys
import json
import threading
from datetime import datetime
from pathlib import Path
import requests
from bs4 import BeautifulSoup
from PIL import Image
from io import BytesIO
from dotenv import load_dotenv, set_key
from woocommerce import API
import re
import html
import uuid
import time

class ImportProduse:
    def __init__(self, root):
        self.root = root
        self.root.title("Export Produse MobileSentrix → CSV (cu Imagini)")
        self.root.geometry("900x700")
        self.root.resizable(True, True)
        
        # Variabile
        self.env_file = Path(".env")
        self.config = {}
        self.wc_api = None
        self.running = False
        
        # Creare directoare
        Path("logs").mkdir(exist_ok=True)
        Path("images").mkdir(exist_ok=True)
        Path("data").mkdir(exist_ok=True)
        
        # Load config
        self.load_config()
        
        # Setup GUI
        self.setup_gui()
        
    def setup_gui(self):
        """Creează interfața grafică"""
        
        # Style
        style = ttk.Style()
        style.theme_use('clam')
        
        # Notebook (tabs)
        notebook = ttk.Notebook(self.root)
        notebook.pack(fill='both', expand=True, padx=10, pady=10)
        
        # Tab 1: Export CSV
        tab_import = ttk.Frame(notebook)
        notebook.add(tab_import, text='📦 Export CSV')
        
        # Tab 2: Configurare
        tab_config = ttk.Frame(notebook)
        notebook.add(tab_config, text='⚙ Configurare')
        
        # Tab 3: Log
        tab_log = ttk.Frame(notebook)
        notebook.add(tab_log, text='📋 Log')
        
        self.setup_import_tab(tab_import)
        self.setup_config_tab(tab_config)
        self.setup_log_tab(tab_log)
        
    def setup_import_tab(self, parent):
        """Setup tab Import"""
        
        # Frame SKU/LINK
        frame_sku = ttk.LabelFrame(parent, text="Selectează fișier cu link-uri sau EAN-uri", padding=10)
        frame_sku.pack(fill='x', padx=10, pady=10)
        
        # Info box despre modul CSV
        info_frame = ttk.Frame(frame_sku)
        info_frame.grid(row=0, column=0, columnspan=3, sticky='ew', pady=(0, 10))
        info_label = ttk.Label(info_frame, text="ℹ️ MOD CSV: Pune link-uri directe din MobileSentrix în sku_list.txt (ex: https://www.mobilesentrix.eu/product-name/) SAU EAN-uri. Program extrage: Nume, Preț EUR/RON, Descriere, Pozele MARI + cont. CSV cu tot.", 
                              foreground="blue", wraplength=800)
        info_label.pack(anchor='w')
        
        self.sku_file_var = tk.StringVar(value="sku_list.txt")
        
        ttk.Label(frame_sku, text="Fișier:").grid(row=1, column=0, sticky='w', padx=5)
        ttk.Entry(frame_sku, textvariable=self.sku_file_var, width=50).grid(row=1, column=1, padx=5)
        ttk.Button(frame_sku, text="Răsfoire...", command=self.browse_sku_file).grid(row=1, column=2, padx=5)
        
        # Opțiuni import
        frame_options = ttk.LabelFrame(parent, text="Opțiuni Import", padding=10)
        frame_options.pack(fill='x', padx=10, pady=10)
        
        self.download_images_var = tk.BooleanVar(value=True)
        self.optimize_images_var = tk.BooleanVar(value=False)  # ❌ DEZACTIVAT - descarcă pozele MARI
        self.convert_price_var = tk.BooleanVar(value=True)
        self.extract_description_var = tk.BooleanVar(value=True)
        self.update_existing_var = tk.BooleanVar(value=True)
        
        ttk.Checkbutton(frame_options, text="Descarcă toate imaginile produsului", 
                       variable=self.download_images_var).grid(row=0, column=0, sticky='w', padx=5, pady=2)
        ttk.Checkbutton(frame_options, text="Optimizează imaginile (resize)", 
                       variable=self.optimize_images_var).grid(row=1, column=0, sticky='w', padx=5, pady=2)
        ttk.Checkbutton(frame_options, text="Convertește prețul EUR → RON", 
                       variable=self.convert_price_var).grid(row=2, column=0, sticky='w', padx=5, pady=2)
        ttk.Checkbutton(frame_options, text="Extrage descriere în română", 
                       variable=self.extract_description_var).grid(row=3, column=0, sticky='w', padx=5, pady=2)
        # Opțiune actualizare produse ASCUNSĂ - nu mai e necesară în modul CSV
        # ttk.Checkbutton(frame_options, text="✅ Actualizează produse existente (dacă SKU există deja)", 
        #                variable=self.update_existing_var).grid(row=4, column=0, sticky='w', padx=5, pady=2)
        
        # Progress
        frame_progress = ttk.Frame(parent)
        frame_progress.pack(fill='x', padx=10, pady=10)
        
        self.progress_var = tk.StringVar(value="Pregătit pentru export CSV")
        ttk.Label(frame_progress, textvariable=self.progress_var).pack(anchor='w')
        
        self.progress_bar = ttk.Progressbar(frame_progress, mode='indeterminate')
        self.progress_bar.pack(fill='x', pady=5)
        
        # Butoane
        frame_buttons = ttk.Frame(parent)
        frame_buttons.pack(fill='x', padx=10, pady=10)
        
        self.btn_start = ttk.Button(frame_buttons, text="🚀 START EXPORT CSV", 
                                     command=self.start_import, style='Accent.TButton')
        self.btn_start.pack(side='left', padx=5)
        
        self.btn_stop = ttk.Button(frame_buttons, text="⛔ STOP", 
                                    command=self.stop_import, state='disabled')
        self.btn_stop.pack(side='left', padx=5)
        
        ttk.Button(frame_buttons, text="📄 Deschide sku_list.txt", 
                  command=lambda: os.startfile("sku_list.txt")).pack(side='right', padx=5)
        
    def setup_config_tab(self, parent):
        """Setup tab Configurare"""
        
        frame = ttk.LabelFrame(parent, text="Configurare WooCommerce API", padding=20)
        frame.pack(fill='both', expand=True, padx=10, pady=10)
        
        # WooCommerce URL
        ttk.Label(frame, text="URL WooCommerce:").grid(row=0, column=0, sticky='w', pady=10)
        self.wc_url_var = tk.StringVar(value=self.config.get('WOOCOMMERCE_URL', 'https://webgsm.ro'))
        ttk.Entry(frame, textvariable=self.wc_url_var, width=50).grid(row=0, column=1, pady=10, padx=10)
        
        # Consumer Key
        ttk.Label(frame, text="Consumer Key:").grid(row=1, column=0, sticky='w', pady=10)
        self.wc_key_var = tk.StringVar(value=self.config.get('WOOCOMMERCE_CONSUMER_KEY', ''))
        ttk.Entry(frame, textvariable=self.wc_key_var, width=50, show='*').grid(row=1, column=1, pady=10, padx=10)
        
        # Consumer Secret
        ttk.Label(frame, text="Consumer Secret:").grid(row=2, column=0, sticky='w', pady=10)
        self.wc_secret_var = tk.StringVar(value=self.config.get('WOOCOMMERCE_CONSUMER_SECRET', ''))
        ttk.Entry(frame, textvariable=self.wc_secret_var, width=50, show='*').grid(row=2, column=1, pady=10, padx=10)
        
        # Curs EUR/RON
        ttk.Label(frame, text="Curs EUR → RON:").grid(row=3, column=0, sticky='w', pady=10)
        self.exchange_rate_var = tk.StringVar(value=self.config.get('EXCHANGE_RATE', '4.97'))
        ttk.Entry(frame, textvariable=self.exchange_rate_var, width=20).grid(row=3, column=1, sticky='w', pady=10, padx=10)
        
        # Butoane
        btn_frame = ttk.Frame(frame)
        btn_frame.grid(row=4, column=0, columnspan=2, pady=20)
        
        ttk.Button(btn_frame, text="💾 Salvează Configurare", 
                  command=self.save_config).pack(side='left', padx=5)
        ttk.Button(btn_frame, text="🔍 Test Conexiune", 
                  command=self.test_connection).pack(side='left', padx=5)
        ttk.Button(btn_frame, text="🔄 Reîncarcă Config", 
                  command=self.reload_config).pack(side='left', padx=5)
        
        # Info box
        info_frame = ttk.LabelFrame(frame, text="ℹ️ Informații", padding=10)
        info_frame.grid(row=5, column=0, columnspan=2, pady=10, sticky='ew')
        
        info_text = """
📍 Cum obții API Keys:
   1. WordPress Admin → WooCommerce → Settings
   2. Tab "Advanced" → Sub-tab "REST API"
   3. Click "Add key"
   4. Description: "Import Produse"
   5. Permissions: "Read/Write"
   6. Generate și copiază Consumer Key și Secret

⚠️ URL fără / la final: https://webgsm.ro (corect)
        """
        ttk.Label(info_frame, text=info_text.strip(), justify='left', 
                 font=('Consolas', 8)).pack(anchor='w')
        
    def setup_log_tab(self, parent):
        """Setup tab Log"""
        
        self.log_text = scrolledtext.ScrolledText(parent, wrap=tk.WORD, 
                                                   font=('Consolas', 9))
        self.log_text.pack(fill='both', expand=True, padx=10, pady=10)
        
        # Butoane
        btn_frame = ttk.Frame(parent)
        btn_frame.pack(fill='x', padx=10, pady=5)
        
        ttk.Button(btn_frame, text="🗑 Șterge Log", 
                  command=lambda: self.log_text.delete(1.0, tk.END)).pack(side='left', padx=5)
        ttk.Button(btn_frame, text="📁 Deschide Folder Logs", 
                  command=lambda: os.startfile("logs")).pack(side='left', padx=5)
        
    def log(self, message, level='INFO'):
        """Adaugă mesaj în log"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        log_entry = f"[{timestamp}] [{level}] {message}\n"
        
        self.log_text.insert(tk.END, log_entry)
        self.log_text.see(tk.END)
        self.root.update()
    
    def cleanup_orphans(self):
        """Curăță produse orfane din WooCommerce (înainte de import)"""
        try:
            self.log("=" * 70, "INFO")
            self.log("🧹 CURĂȚARE ORFANE - Găsire și ștergere produse incomplete", "INFO")
            self.log("=" * 70, "INFO")
            
            if not self.wc_api:
                # Inițializează API
                self.wc_api = API(
                    url=self.config['WOOCOMMERCE_URL'],
                    consumer_key=self.config['WOOCOMMERCE_CONSUMER_KEY'],
                    consumer_secret=self.config['WOOCOMMERCE_CONSUMER_SECRET'],
                    version="wc/v3",
                    timeout=30
                )
            
            # Caută TOATE produsele (cu pagina mare)
            self.log("📊 Descarcă lista completă de produse din WooCommerce...", "INFO")
            all_products = []
            page = 1
            per_page = 100
            max_pages = 50  # Safety limit
            
            while page <= max_pages:
                try:
                    response = self.wc_api.get("products", params={"page": page, "per_page": per_page, "status": "any"})
                    
                    if response.status_code != 200:
                        self.log(f"⚠️ Status {response.status_code} la pagina {page} - Opresc descărcarea", "WARNING")
                        break
                    
                    products = response.json()
                    if not products or len(products) == 0:
                        self.log(f"  📖 Pagina {page}: 0 produse - Am ajuns la final", "INFO")
                        break
                    
                    all_products.extend(products)
                    self.log(f"  📖 Pagina {page}: {len(products)} produse", "INFO")
                    page += 1
                    
                except Exception as page_error:
                    self.log(f"⚠️ Eroare la pagina {page}: {page_error}", "WARNING")
                    break
            
            if len(all_products) == 0:
                self.log("⚠️ API-ul returnează 0 produse! Posibil probleme cu API sau autentificare.", "WARNING")
                self.log("🔍 Voi incerca să identific orfane prin alt metod...", "INFO")
                
                # Fallback: Încearcă o cerere simplă
                try:
                    simple_response = self.wc_api.get("products")
                    simple_products = simple_response.json()
                    if simple_products and len(simple_products) > 0:
                        all_products = simple_products
                        self.log(f"✓ Am găsit {len(all_products)} produse cu metoda alternativă", "INFO")
                except:
                    pass
            
            # Dacă inca nu au produse, încearcă fără parametri
            if len(all_products) == 0:
                self.log("⚠️ Curățare orfane nu a putut descărca produse. Continuez importul...", "WARNING")
                self.log("💡 Dacă apare 'Duplicate entry', programul va curăța automat.", "INFO")
                return
            
            self.log(f"✓ Total descărcat: {len(all_products)} produse", "INFO")
            
            # Identifică produse problematice (fără SKU valid sau cu meta_data incompletă)
            orphans_to_delete = []
            
            for prod in all_products:
                product_id = prod.get('id')
                product_sku = prod.get('sku', '')
                product_status = prod.get('status', '')
                product_name = prod.get('name', 'N/A')
                
                # Verifică dacă e produs incomplet:
                has_ean = any(m.get('key') == '_ean' for m in prod.get('meta_data', []))
                
                if product_sku.startswith('WEBGSM-') and (product_status in ['trash', 'draft'] or not has_ean):
                    orphans_to_delete.append({
                        'id': product_id,
                        'sku': product_sku,
                        'status': product_status,
                        'name': product_name
                    })
            
            if not orphans_to_delete:
                self.log("✅ Nu sunt orfane! Baza de date e curată.", "SUCCESS")
                return
            
            self.log(f"⚠️ Găsite {len(orphans_to_delete)} produse incomplete/orfane:", "WARNING")
            
            for orphan in orphans_to_delete:
                self.log(f"   ID: {orphan['id']} | SKU: {orphan['sku']} | Status: {orphan['status']}", "WARNING")
            
            # Șterge orfanele
            deleted_count = 0
            for orphan in orphans_to_delete:
                try:
                    response = self.wc_api.delete(f"products/{orphan['id']}", params={"force": True})
                    if response.status_code in [200, 204]:
                        deleted_count += 1
                        self.log(f"   ✓ Șters ID {orphan['id']}", "SUCCESS")
                    else:
                        self.log(f"   ✗ Nu s-a putut șterge ID {orphan['id']} (status {response.status_code})", "ERROR")
                except Exception as e:
                    self.log(f"   ✗ Eroare la ștergere ID {orphan['id']}: {e}", "ERROR")
            
            self.log(f"🧹 Curățare completă: {deleted_count}/{len(orphans_to_delete)} orfane șterse", "INFO")
            self.log("=" * 70, "INFO")
            
        except Exception as e:
            self.log(f"❌ Eroare curățare: {e}", "ERROR")
    
    def load_config(self):
        """Încarcă configurația din .env"""
        # Setări default
        self.config = {
            'WOOCOMMERCE_URL': 'https://webgsm.ro',
            'WOOCOMMERCE_CONSUMER_KEY': '',
            'WOOCOMMERCE_CONSUMER_SECRET': '',
            'EXCHANGE_RATE': '4.97'
        }
        
        # Încarcă din .env dacă există
        if self.env_file.exists():
            try:
                load_dotenv(self.env_file)
                self.config = {
                    'WOOCOMMERCE_URL': os.getenv('WOOCOMMERCE_URL', 'https://webgsm.ro'),
                    'WOOCOMMERCE_CONSUMER_KEY': os.getenv('WOOCOMMERCE_CONSUMER_KEY', ''),
                    'WOOCOMMERCE_CONSUMER_SECRET': os.getenv('WOOCOMMERCE_CONSUMER_SECRET', ''),
                    'EXCHANGE_RATE': os.getenv('EXCHANGE_RATE', '4.97')
                }
                print(f"✓ Config încărcat din .env: {self.config}")
            except Exception as e:
                print(f"✗ Eroare la încărcarea config: {e}")
        else:
            print("ℹ Fișierul .env nu există, folosim valori default")
        
    def save_config(self):
        """Salvează configurația în .env"""
        try:
            # Validare date
            url = self.wc_url_var.get().strip()
            key = self.wc_key_var.get().strip()
            secret = self.wc_secret_var.get().strip()
            rate = self.exchange_rate_var.get().strip()
            
            if not url:
                messagebox.showwarning("Atenție", "URL-ul WooCommerce este obligatoriu!")
                return
            
            if not key or not secret:
                messagebox.showwarning("Atenție", "Consumer Key și Secret sunt obligatorii!")
                return
            
            # Verifică URL (elimină / de la final dacă există)
            if url.endswith('/'):
                url = url[:-1]
                self.wc_url_var.set(url)
            
            # Validare curs valutar
            try:
                float(rate)
            except ValueError:
                messagebox.showwarning("Atenție", "Cursul valutar trebuie să fie un număr valid!")
                return
            
            # Crează sau actualizează .env
            with open(self.env_file, 'w', encoding='utf-8') as f:
                f.write(f"WOOCOMMERCE_URL={url}\n")
                f.write(f"WOOCOMMERCE_CONSUMER_KEY={key}\n")
                f.write(f"WOOCOMMERCE_CONSUMER_SECRET={secret}\n")
                f.write(f"EXCHANGE_RATE={rate}\n")
            
            # Actualizează config intern
            self.config = {
                'WOOCOMMERCE_URL': url,
                'WOOCOMMERCE_CONSUMER_KEY': key,
                'WOOCOMMERCE_CONSUMER_SECRET': secret,
                'EXCHANGE_RATE': rate
            }
            
            # Resetează API pentru a folosi noile credențiale
            self.wc_api = None
            
            self.log("✓ Configurație salvată cu succes!", "SUCCESS")
            self.log(f"   URL: {url}", "INFO")
            self.log(f"   Curs: {rate} RON/EUR", "INFO")
            messagebox.showinfo("Succes", "Configurația a fost salvată!\n\nPoți testa conexiunea acum.")
            
        except Exception as e:
            self.log(f"✗ Eroare salvare configurație: {e}", "ERROR")
            import traceback
            self.log(f"   Traceback: {traceback.format_exc()}", "ERROR")
            messagebox.showerror("Eroare", f"Nu s-a putut salva configurația:\n{e}")
    
    def reload_config(self):
        """Reîncarcă configurația din .env"""
        try:
            self.load_config()
            
            # Actualizează câmpurile GUI
            self.wc_url_var.set(self.config.get('WOOCOMMERCE_URL', 'https://webgsm.ro'))
            self.wc_key_var.set(self.config.get('WOOCOMMERCE_CONSUMER_KEY', ''))
            self.wc_secret_var.set(self.config.get('WOOCOMMERCE_CONSUMER_SECRET', ''))
            self.exchange_rate_var.set(self.config.get('EXCHANGE_RATE', '4.97'))
            
            self.log("🔄 Configurație reîncărcată din .env", "INFO")
            messagebox.showinfo("Succes", "Configurația a fost reîncărcată din fișier!")
            
        except Exception as e:
            self.log(f"✗ Eroare reîncarcare config: {e}", "ERROR")
            messagebox.showerror("Eroare", f"Nu s-a putut reîncărca configurația:\n{e}")
    
    def generate_unique_sku(self, ean):
        """Generează SKU unic pentru WooCommerce bazat pe EAN"""
        # Format: WEBGSM-[ultimi 6 cifre EAN]-[timestamp scurt]
        import time
        
        # Extrage ultimi 6 cifre din EAN
        ean_suffix = str(ean)[-6:] if len(str(ean)) >= 6 else str(ean)
        
        # Timestamp scurt (4 cifre)
        timestamp = str(int(time.time()))[-4:]
        
        # Generează SKU
        sku = f"WEBGSM-{ean_suffix}-{timestamp}"
        
        return sku
    
    def test_connection(self):
        """Testează conexiunea la WooCommerce"""
        try:
            self.log("Testez conexiunea la WooCommerce...", "INFO")
            
            wcapi = API(
                url=self.wc_url_var.get(),
                consumer_key=self.wc_key_var.get(),
                consumer_secret=self.wc_secret_var.get(),
                version="wc/v3",
                timeout=30
            )
            
            # Test request
            response = wcapi.get("products", params={"per_page": 1})
            
            if response.status_code == 200:
                self.log("✓ Conexiune reușită la WooCommerce!", "SUCCESS")
                messagebox.showinfo("Succes", "Conexiunea la WooCommerce este funcțională!")
                self.wc_api = wcapi
            else:
                self.log(f"✗ Eroare conexiune: Status {response.status_code}", "ERROR")
                messagebox.showerror("Eroare", f"Status Code: {response.status_code}\n{response.text}")
                
        except Exception as e:
            self.log(f"✗ Eroare conexiune: {e}", "ERROR")
            messagebox.showerror("Eroare", f"Nu s-a putut conecta la WooCommerce:\n{e}")
    
    def browse_sku_file(self):
        """Selectează fișier SKU"""
        filename = filedialog.askopenfilename(
            title="Selectează fișierul cu SKU-uri",
            filetypes=[("Text Files", "*.txt"), ("All Files", "*.*")]
        )
        if filename:
            self.sku_file_var.set(filename)
    
    def start_import(self):
        """Pornește importul"""
        if not Path(self.sku_file_var.get()).exists():
            messagebox.showerror("Eroare", f"Fișierul {self.sku_file_var.get()} nu există!")
            return
        
        if not self.wc_api:
            reply = messagebox.askyesno("Atenție", 
                "Nu ai testat conexiunea la WooCommerce.\nContinui oricum?")
            if not reply:
                return
        
        self.running = True
        self.btn_start.config(state='disabled')
        self.btn_stop.config(state='normal')
        self.progress_bar.start()
        
        # Rulează import în thread separat
        thread = threading.Thread(target=self.run_import, daemon=True)
        thread.start()
    
    def stop_import(self):
        """Oprește importul"""
        self.running = False
        self.log("⛔ Import oprit de utilizator", "WARNING")
        self.progress_bar.stop()
        self.btn_start.config(state='normal')
        self.btn_stop.config(state='disabled')
        self.progress_var.set("Import oprit")
    
    def run_import(self):
        """Execută exportul în CSV (NU mai inserează în WooCommerce)"""
        try:
            self.log("=" * 70, "INFO")
            self.log("🚀 START EXPORT PRODUSE ÎN CSV (Mod CSV - fără WooCommerce)", "INFO")
            self.log("=" * 70, "INFO")
            
            # Citește SKU-uri
            skus = self.read_sku_file(self.sku_file_var.get())
            self.log(f"📋 Găsite {len(skus)} SKU-uri pentru procesare", "INFO")
            
            success_count = 0
            error_count = 0
            products_data = []  # Lista pentru CSV
            
            for idx, sku in enumerate(skus, 1):
                if not self.running:
                    break
                
                self.progress_var.set(f"Procesez produs {idx}/{len(skus)}: {sku}")
                self.log(f"\n" + "="*70, "INFO")
                self.log(f"[{idx}/{len(skus)}] 🔵 START procesare EAN: {sku}", "INFO")
                self.log(f"="*70, "INFO")
                
                try:
                    # Scraping produs de pe MobileSentrix
                    product_data = self.scrape_product(sku)
                    
                    if product_data:
                        # Adaugă SKU generat
                        product_data['sku'] = self.generate_unique_sku(sku)
                        product_data['ean'] = sku
                        
                        # Salvează în listă pentru CSV
                        products_data.append(product_data)
                        success_count += 1
                        self.log(f"✓ Produs procesat cu succes! (pozele au fost salvate local)", "SUCCESS")
                    else:
                        error_count += 1
                        self.log(f"✗ Nu s-au putut extrage datele produsului", "ERROR")
                        
                except Exception as e:
                    error_count += 1
                    self.log(f"✗ Eroare: {e}", "ERROR")
            
            # CREARE CSV
            csv_filename = None
            csv_path = None
            if products_data:
                self.log("\n" + "=" * 70, "INFO")
                self.log("📝 CREARE FIȘIER CSV...", "INFO")
                self.log("=" * 70, "INFO")
                
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                csv_filename = f"export_produse_{timestamp}.csv"
                csv_path = self.export_to_csv(products_data, csv_filename)
                
                if csv_path:
                    self.log(f"\n✅ CSV creat: {csv_path}", "SUCCESS")
            
            # Sumar final
            self.log("\n" + "=" * 70, "INFO")
            self.log(f"📊 SUMAR EXPORT:", "INFO")
            self.log(f"   ✓ Produse procesate cu succes: {success_count}", "SUCCESS")
            self.log(f"   ✗ Erori: {error_count}", "ERROR")
            self.log(f"   📦 Total SKU-uri: {len(skus)}", "INFO")
            self.log(f"   📁 Imagini salvate în: images/", "INFO")
            self.log("=" * 70, "INFO")
            
            csv_info = f"\nFișier CSV: {csv_filename}" if csv_filename else ""
            messagebox.showinfo("Finalizat", 
                f"Export finalizat!\n\nProduse procesate: {success_count}\nErori: {error_count}{csv_info}\nFolderul imagini: images/")
            
            # Deschide folderul data cu CSV-ul
            if csv_path:
                os.startfile(Path("data"))
            
        except Exception as e:
            self.log(f"✗ Eroare critică: {e}", "ERROR")
            messagebox.showerror("Eroare", f"Eroare critică:\n{e}")
            
        finally:
            self.progress_bar.stop()
            self.btn_start.config(state='normal')
            self.btn_stop.config(state='disabled')
            self.progress_var.set("Export finalizat")
            self.running = False
    
    def read_sku_file(self, filepath):
        """Citește link-uri, EAN-uri sau SKU-uri din fișier
        Acceptă:
        - URL direct: https://www.mobilesentrix.eu/...
        - SKU: 107182127516 (12-13 cifre)
        - EAN: 888888888888 (12-13 cifre - mai rar)
        """
        items = []
        with open(filepath, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#'):
                    items.append(line)
        return items
    
    def export_to_csv(self, products_data, filename="export_produse.csv"):
        """Exportă produsele în CSV cu toate informațiile inclusiv pozele"""
        import csv
        
        try:
            csv_path = Path("data") / filename
            self.log(f"📄 Creez fișier CSV: {csv_path}", "INFO")
            
            with open(csv_path, 'w', newline='', encoding='utf-8-sig') as csvfile:
                fieldnames = ['EAN', 'SKU', 'Nume', 'Preț EUR', 'Preț RON', 'Descriere', 
                             'Stock', 'Brand', 'Tags', 'Imagine Principală', 'Imagini Suplimentare', 'Total Imagini']
                writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
                
                writer.writeheader()
                
                for product in products_data:
                    # Colectează path-urile imaginilor
                    image_paths = []
                    if product.get('images'):
                        for img in product['images']:
                            if 'local_path' in img:
                                image_paths.append(img['local_path'])
                    
                    # Calculează preț RON
                    price_ron = product['price']
                    if self.convert_price_var.get():
                        exchange_rate = float(self.exchange_rate_var.get())
                        price_ron = product['price'] * exchange_rate
                    
                    # Curăță numele (elimină " Copy" de la sfârșit)
                    clean_name = product.get('name', 'N/A')
                    if clean_name.endswith(' Copy'):
                        clean_name = clean_name[:-5]  # Elimină ultimele 5 caractere (" Copy")
                    
                    # Curăță descrierea (elimină URL-uri)
                    clean_desc = product.get('description', '')[:500]
                    import re
                    clean_desc = re.sub(r'https?://\S+', '', clean_desc).strip()  # Elimină toate URL-urile
                    
                    row = {
                        'EAN': product.get('ean_real', ''),  # EAN real sau gol
                        'SKU': product.get('sku', 'N/A'),
                        'Nume': clean_name,
                        'Preț EUR': f"{product['price']:.2f}",
                        'Preț RON': f"{price_ron:.2f}",
                        'Descriere': clean_desc,
                        'Stock': product.get('stock', '100'),  # Stock default 100
                        'Brand': product.get('brand', 'MobileSentrix'),  # Brand default
                        'Tags': product.get('tags', ''),  # Tags
                        'Imagine Principală': image_paths[0] if image_paths else '',
                        'Imagini Suplimentare': '; '.join(image_paths[1:]) if len(image_paths) > 1 else '',
                        'Total Imagini': len(image_paths)
                    }
                    writer.writerow(row)
            
            self.log(f"✓ CSV creat cu succes: {csv_path}", "SUCCESS")
            self.log(f"   📊 Total produse exportate: {len(products_data)}", "INFO")
            return str(csv_path)
            
        except Exception as e:
            self.log(f"✗ Eroare creare CSV: {e}", "ERROR")
            import traceback
            self.log(f"   Traceback: {traceback.format_exc()}", "ERROR")
            return None
    
    def scrape_product(self, ean):
        """Extrage date produs de pe MobileSentrix și descarcă imagini local
        Acceptă: EAN, SKU sau LINK DIRECT la produs"""
        try:
            import re  # ⬅️ IMPORTANT: Import la ÎNCEPUTUL funcției!
            
            product_link = None
            product_id = ean  # Va fi folosit pentru nume fișiere
            
            # Headers pentru toate request-urile
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Accept-Language': 'ro-RO,ro;q=0.9,en;q=0.8',
                'Referer': 'https://www.mobilesentrix.eu/'
            }
            
            # PASUL 1: Detectează dacă input-ul e link direct
            if ean.startswith('http://') or ean.startswith('https://'):
                # E link direct! 🎯
                product_link = ean
                # Extrage un ID simplu din URL pentru nume fișiere (ultimul segment URL)
                product_id = ean.rstrip('/').split('/')[-1][:50]  # Max 50 caractere
                # Curăță caracterele invalide pentru Windows filenames
                product_id = re.sub(r'[<>:"/\\|?*]', '_', product_id)
                self.log(f"   ✓ Link direct detectat!", "INFO")
                self.log(f"      URL: {product_link[:80]}...", "INFO")
                self.log(f"      ID produs: {product_id}", "INFO")
                
                # ⬇️ IMPORTANT: Descarcă pagina produsului!
                self.log(f"   🔄 Se descarcă pagina produsului...", "INFO")
                response = requests.get(product_link, headers=headers, timeout=30)
                response.raise_for_status()
                product_soup = BeautifulSoup(response.content, 'html.parser')
            # PASUL 1b: Detectează dacă e SKU (12-13 cifre consecutive)
            elif re.match(r'^\d{10,14}$', ean.strip()):
                # E SKU/EAN - MobileSentrix acceptă SKU în URL direct!
                # Caută produsul pe baza SKU în pagina de căutare
                search_sku = ean.strip()
                search_url = f"https://www.mobilesentrix.eu/catalogsearch/result/?q={search_sku}"
                self.log(f"   🔍 Căutare produs cu SKU: {search_sku}", "INFO")
                
                response = requests.get(search_url, headers=headers, timeout=30)
                response.raise_for_status()
                soup = BeautifulSoup(response.content, 'html.parser')
                
                # ===== DEBUG: Salvează HTML pentru inspecție =====
                debug_file = Path("logs") / f"debug_search_{search_sku}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.html"
                with open(debug_file, 'w', encoding='utf-8') as f:
                    f.write(soup.prettify())
                self.log(f"   📝 HTML căutare salvat: {debug_file}", "INFO")
                
                # Găsește primul produs valid din rezultate
                product_links = soup.select('a.product-item-link')
                
                if not product_links:
                    self.log(f"   ✗ Nu am găsit produse pentru SKU {search_sku}", "ERROR")
                    return None
                
                # Folosește primul link
                product_link = product_links[0].get('href')
                product_id = search_sku  # Folosim SKU-ul ca ID pentru fișiere
                
                if not product_link:
                    self.log(f"   ✗ Link produs invalid", "ERROR")
                    return None
                
                self.log(f"   ✓ Produs găsit! Link: {product_link[:80]}...", "INFO")
                
                # ⬇️ IMPORTANT: Descarcă pagina produsului!
                self.log(f"   🔄 Se descarcă pagina produsului...", "INFO")
                response = requests.get(product_link, headers=headers, timeout=30)
                response.raise_for_status()
                product_soup = BeautifulSoup(response.content, 'html.parser')
            else:
                # E text generic EAN/SKU - trebuie să căutam
                
                response = requests.get(search_url, headers=headers, timeout=30)
                response.raise_for_status()
                soup = BeautifulSoup(response.content, 'html.parser')
                
                # ===== DEBUG: Salvează HTML pentru inspecție =====
                debug_file = Path("logs") / f"debug_search_{ean}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.html"
                with open(debug_file, 'w', encoding='utf-8') as f:
                    f.write(soup.prettify())
                self.log(f"   📝 HTML salvat în: {debug_file}", "INFO")
                
                # Căuta orice link-uri de produs
                all_product_links = []
                
                # Căută cu selectorii specifici pentru produse
                product_selectors = [
                    'a.product-item-link',
                    'a.product.photo',
                    'a[data-product-id]',
                    'a[href*="/product/"]',
                    'a[href*="/catalogsearch/result/"]'
                ]
                
                for selector in product_selectors:
                    found = soup.select(selector)
                    if found:
                        self.log(f"   Selector '{selector}' a găsit {len(found)} link-uri", "INFO")
                        all_product_links.extend(found)
                
                # Elimină duplicatele și filtrează
                unique_links = []
                seen_hrefs = set()
                for link in all_product_links:
                    href = link.get('href', '')
                    if href and href not in seen_hrefs and 'mobilesentrix.eu' in href:
                        seen_hrefs.add(href)
                        unique_links.append(link)
                
                self.log(f"   🔎 Total link-uri găsite: {len(unique_links)}", "INFO")
                
                if not unique_links:
                    # ❌ NU am găsit nimic
                    self.log(f"   ⚠️ NU AM GĂSIT PRODUSUL cu EAN/SKU {ean} pe MobileSentrix!", "WARNING")
                    self.log(f"   💡 SOLUȚII:", "INFO")
                    self.log(f"      1. Copiază LINK DIRECT din MobileSentrix", "INFO")
                    self.log(f"      2. Pune link-ul în sku_list.txt (în loc de EAN)", "INFO")
                    self.log(f"      3. Programul va extrage datele direct!", "INFO")
                    return None
                
                # Folosește primul link valid
                product_link = unique_links[0]['href']
                self.log(f"   ✓ Link produs găsit: {product_link}", "INFO")
                
                # ⬇️ IMPORTANT: Descarcă pagina produsului!
                self.log(f"   🔄 Se descarcă pagina produsului...", "INFO")
                response = requests.get(product_link, headers=headers, timeout=30)
                response.raise_for_status()
                product_soup = BeautifulSoup(response.content, 'html.parser')
            
            # Extrage ID produs intern (230473) - unic pe MobileSentrix
            product_id_internal = None
            # Caută în variabila JavaScript: var magicToolboxProductId = 230473;
            script_content = str(product_soup)
            id_match = re.search(r'var\s+magicToolboxProductId\s*=\s*(\d+)', script_content)
            if id_match:
                product_id_internal = id_match.group(1)
                self.log(f"   ✓ ID produs intern găsit: {product_id_internal}", "INFO")
            
            # Căută și în atribut data-product-id
            if not product_id_internal:
                id_elem = product_soup.select_one('[data-product-id], input[name="product"][value]')
                if id_elem:
                    product_id_internal = id_elem.get('value') or id_elem.get('data-product-id')
                    if product_id_internal:
                        self.log(f"   ✓ ID produs din atribut: {product_id_internal}", "INFO")
            
            # Salvează HTML pentru SKU extraction din JavaScript
            product_page_html = str(product_soup)
            
            # ===== DEBUG: Salvează HTML produsului =====
            debug_product_file = Path("logs") / f"debug_product_{datetime.now().strftime('%Y%m%d_%H%M%S')}.html"
            with open(debug_product_file, 'w', encoding='utf-8') as f:
                f.write(product_soup.prettify())
            self.log(f"   📝 HTML produs salvat: {debug_product_file}", "INFO")
            
            # Extrage nume produs - MULTIPLI SELECTORII
            product_name = None
            name_selectors = [
                '.page-title span',
                'h1.page-title',
                'h1[itemprop="name"]',
                '.product-name',
                'h1',
                '.product-info-main h1'
            ]
            
            for selector in name_selectors:
                name_elem = product_soup.select_one(selector)
                if name_elem:
                    product_name = name_elem.text.strip()
                    self.log(f"   ✓ Nume găsit cu: {selector}", "INFO")
                    break
            
            if not product_name:
                product_name = f"Produs {ean}"
                self.log(f"   ⚠️ NU am găsit nume produs - folosesc placeholder", "WARNING")
            
            # Curăță numele de text garbage și caractere nevalide
            import re
            # Elimină "Copy", "EAN:", și alte text nevrut
            product_name = re.sub(r'\s*\bCopy\b\s*', '', product_name)
            product_name = re.sub(r'\s*\bEAN:.*', '', product_name)
            product_name = re.sub(r'\s*\bSKU:.*', '', product_name)
            product_name = re.sub(r'\s+', ' ', product_name)  # Normalizează spații multiple
            product_name = product_name.strip()
            
            # Extrage preț (EUR) - MULTIPLI SELECTORII
            price = 0.0
            price_selectors = [
                '.price-wrapper .price',
                '.product-info-price .price',
                'span[data-price-type="finalPrice"]',
                '.price-box .price',
                '.product-price .price',
                'span.price',
                '[itemprop="price"]'
            ]
            
            for selector in price_selectors:
                price_elem = product_soup.select_one(selector)
                if price_elem:
                    price_text = price_elem.text.strip()
                    # Extrage doar numerele și convertește la float
                    import re
                    price_match = re.search(r'[\d,\.]+', price_text.replace(',', '.'))
                    if price_match:
                        price = float(price_match.group(0))
                        self.log(f"   ✓ Preț găsit cu: {selector}", "INFO")
                        break
            
            if price == 0.0:
                self.log(f"   ⚠️ NU am găsit preț - folosesc 0.00", "WARNING")
            
            self.log(f"   📦 Nume: {product_name}", "INFO")
            self.log(f"   💶 Preț: {price:.2f} EUR", "INFO")
            
            # Extrage descriere
            description = ""
            desc_selectors = [
                '.product.attribute.description .value',
                '.product-description',
                '[itemprop="description"]',
                '.product-info-description'
            ]
            
            for desc_sel in desc_selectors:
                desc_elem = product_soup.select_one(desc_sel)
                if desc_elem:
                    description = desc_elem.get_text(strip=True)
                    if description:
                        break
            
            # Curăță descrierea de text garbage
            import re
            # Elimină liniile cu "Copy", "EAN", "SKU", "Share" și alte gunoaie
            lines = description.split('\n')
            clean_lines = []
            for line in lines:
                line = line.strip()
                # Sări linii care conțin cuvinte de ignorat
                if any(skip in line for skip in ['Copy', 'Share', 'Email', 'WhatsApp', 'FAQ', 'Contact', 'EAN:', 'SKU:', 'Add to']):
                    continue
                # Sări linii prea scurte (probably UI text)
                if len(line) < 3:
                    continue
                clean_lines.append(line)
            
            description = ' '.join(clean_lines)[:1000]  # Max 1000 caractere
            
            # Elimină URL-uri și alte caractere speciale
            description = re.sub(r'https?://\S+', '', description).strip()
            description = re.sub(r'\s+', ' ', description)  # Normalizează whitespace
            
            if not description:
                description = f"Produs {product_name}"
            
            # Extrage imagini
            images_data = []
            
            if self.download_images_var.get():
                self.log(f"   🖼️ Descarc imagini MARI...", "INFO")
                
                # 🎯 CAUTĂ IMAGINILE ÎN META TAGS + GALERIE COMPLETĂ
                img_urls = set()
                
                # 1. Meta tags Open Graph (imaginea principală)
                og_images = product_soup.find_all('meta', property='og:image')
                for og_img in og_images:
                    if og_img.get('content'):
                        img_urls.add(og_img['content'])
                        self.log(f"      ✓ Găsită imagine în og:image", "INFO")
                
                # 2. JSON-LD structured data (poate conține array de imagini)
                json_ld_scripts = product_soup.find_all('script', type='application/ld+json')
                for script in json_ld_scripts:
                    try:
                        import json
                        data = json.loads(script.string)
                        if isinstance(data, dict) and 'image' in data:
                            images = data['image']
                            if isinstance(images, str):
                                img_urls.add(images)
                            elif isinstance(images, list):
                                for img in images:
                                    if isinstance(img, str):
                                        img_urls.add(img)
                                    elif isinstance(img, dict) and 'url' in img:
                                        img_urls.add(img['url'])
                                self.log(f"      ✓ Găsite {len(images) if isinstance(images, list) else 1} imagini în JSON-LD", "INFO")
                    except:
                        pass
                
                # 3. 🔥 GALERIA MAGICZOOM - aici sunt TOATE imaginile!
                magic_zoom_links = product_soup.find_all('a', {'data-zoom-id': True})
                for link in magic_zoom_links:
                    href = link.get('href')
                    if href and '/catalog/product/' in href:
                        img_urls.add(href)
                self.log(f"      ✓ Găsite {len(magic_zoom_links)} imagini în galeria MagicZoom", "INFO")
                
                # 4. Link-uri cu atribut data-image (thumbnail gallery)
                data_image_links = product_soup.find_all('a', {'data-image': True})
                for link in data_image_links:
                    href = link.get('href')
                    if href and '/catalog/product/' in href:
                        img_urls.add(href)
                
                # 5. Fallback: caută imagini în elemente img standard
                img_selectors = [
                    '.product-image-photo',
                    'img[data-role="image"]',
                    '.product-photo img',
                    '.gallery-placeholder img'
                ]
                for selector in img_selectors:
                    for img_elem in product_soup.select(selector):
                        src = img_elem.get('src') or img_elem.get('data-src')
                        if src and 'catalog/product' in src:
                            img_urls.add(src)
                
                if not img_urls:
                    self.log(f"   ⚠️ Nu am găsit imagini pe pagina produsului", "WARNING")
                else:
                    self.log(f"   🔍 Total imagini găsite: {len(img_urls)}", "INFO")
                
                for idx, img_url in enumerate(list(img_urls)[:10], 1):  # Max 10 imagini
                    # Dacă URL e relativ, fă-l absolut
                    if img_url.startswith('/'):
                        img_url = 'https://www.mobilesentrix.eu' + img_url
                    elif not img_url.startswith('http'):
                        img_url = 'https://www.mobilesentrix.eu/' + img_url
                    
                    # Convertește thumbnail în imagine MARE
                    # De exemplu: /thumbnail/ -> /image/ sau /small_image/ -> /image/
                    img_url = img_url.replace('/thumbnail/', '/image/').replace('/small_image/', '/image/')
                    
                    try:
                        # Descarcă imaginea în dimensiunea MARE (originală)
                        self.log(f"      📷 [{idx}] Descarc: {img_url[:80]}...", "INFO")
                        img_response = requests.get(img_url, headers=headers, timeout=30)
                        img_response.raise_for_status()
                        
                        # Deschide imagine cu PIL
                        img = Image.open(BytesIO(img_response.content))
                        
                        # ❌ NU optimizezi - salvează original MARE
                        # (comentat codul de resize)
                        # if self.optimize_images_var.get():
                        #     max_size = (1200, 1200)
                        #     img.thumbnail(max_size, Image.Resampling.LANCZOS)
                        
                        # Generează nume fișier unic
                        img_extension = img.format.lower() if img.format else 'jpg'
                        img_filename = f"{product_id}_{idx}.{img_extension}"
                        img_path = Path("images") / img_filename
                        
                        # Salvează imaginea local - dimensiunea ORIGINALĂ
                        img.save(img_path, quality=95)  # Max quality
                        file_size = img_path.stat().st_size / (1024 * 1024)  # Size în MB
                        self.log(f"         ✓ Salvat: {img_filename} ({file_size:.2f} MB)", "SUCCESS")
                        
                        # Adaugă în lista de imagini cu path local
                        images_data.append({
                            'src': img_url,  # URL original (pentru referință)
                            'local_path': str(img_path),  # Path local pentru CSV
                            'name': img_filename,
                            'size': f"{file_size:.2f} MB"
                        })
                        
                        # Rate limit - pauză între descărcări
                        time.sleep(0.5)
                        
                    except Exception as img_error:
                        self.log(f"         ⚠️ Eroare descarcare imagine {idx}: {img_error}", "WARNING")
                
                self.log(f"   ✓ Total imagini descarcate: {len(images_data)}", "SUCCESS")
            
            # Extrage brand din nume (de obicei primul cuvânt sau "iPhone", "Samsung" etc)
            brand = 'MobileSentrix'  # Default
            if 'iPhone' in product_name or 'Apple' in product_name:
                brand = 'Apple'
            elif 'Samsung' in product_name or 'Galaxy' in product_name:
                brand = 'Samsung'
            elif 'Google' in product_name or 'Pixel' in product_name:
                brand = 'Google'
            
            # 🎯 EXTRAGE SKU-UL REAL DE LA MOBILESENTRIX DIN JAVASCRIPT
            extracted_sku = None
            try:
                import re
                # Caută variabila ecommerce.items.item_id în JavaScript
                # Pattern: var ecommerce = {...,"item_id":"107182127516",...}
                ecommerce_pattern = r'var ecommerce\s*=\s*{[^}]*"item_id"\s*:\s*"(\d+)"'
                ecommerce_match = re.search(ecommerce_pattern, product_page_html)
                
                if ecommerce_match:
                    extracted_sku = ecommerce_match.group(1)
                    self.log(f"   ✓ SKU MobileSentrix extras din JavaScript: {extracted_sku}", "SUCCESS")
            except Exception as sku_extract_error:
                self.log(f"   ⚠️ Nu am putut extrage SKU din JavaScript: {sku_extract_error}", "WARNING")
            
            # Generează SKU din ID produsului intern sau folosește cel extras
            if extracted_sku:
                # Dacă am extras SKU-ul de la MobileSentrix, îl folosim direct!
                generated_sku = extracted_sku
                self.log(f"   ✓ SKU folosit: {generated_sku} (de la MobileSentrix)", "INFO")
            elif product_id_internal:
                # Fallback: SKU generat din ID intern
                generated_sku = f"MS-{product_id_internal}"
                self.log(f"   ✓ SKU generat din ID produs: {generated_sku}", "INFO")
            else:
                # Fallback: din URL slug
                import re
                sku_base = re.sub(r'[^a-zA-Z0-9-]', '', product_id[:20].upper())  # Max 20 chars alfanumerice
                generated_sku = f"MS-{sku_base}"
                self.log(f"   ✓ SKU generat din URL: {generated_sku}", "INFO")
            
            # Tag-uri din categorii (extrage din nume)
            tags = []
            if 'iPhone' in product_name:
                tags.append('iPhone')
            if 'Pro Max' in product_name:
                tags.append('Pro Max')
            if 'Charging' in product_name or 'Port' in product_name:
                tags.append('Charging Port')
            if 'Premium' in product_name:
                tags.append('Premium')
            if 'Genuine' in product_name or 'OEM' in product_name:
                tags.append('OEM')
            
            product_data = {
                'ean': ean if not ean.startswith('http') else product_link,  # Pentru logging
                'ean_real': '',  # MobileSentrix NU expune EAN public
                'sku': generated_sku,  # SKU generat din ID intern
                'name': product_name,
                'price': price,
                'description': description,
                'stock': '100',  # Stock default
                'brand': brand,
                'tags': ', '.join(tags),
                'images': images_data
            }
            
            self.log(f"   ✓ Date extrase cu succes!", "SUCCESS")
            
            return product_data
            
        except requests.exceptions.RequestException as req_error:
            self.log(f"   ✗ Eroare conexiune: {req_error}", "ERROR")
            return None
        except Exception as e:
            self.log(f"   ✗ Eroare scraping: {e}", "ERROR")
            import traceback
            self.log(f"   📝 Traceback: {traceback.format_exc()}", "ERROR")
            return None
    
    def cleanup_phantom_from_mysql(self, product_id):
        """Șterge phantom product direct din MySQL (dacă API nu funcționează)"""
        try:
            # Extrage credentialele MySQL din .env sau config
            db_host = os.getenv('DB_HOST', 'localhost')
            db_user = os.getenv('DB_USER', 'root')
            db_pass = os.getenv('DB_PASSWORD', '')
            db_name = os.getenv('DB_NAME', 'wordpress')
            
            # Încearcă import - MySQL nu e instalat pe client deci NU merge
            # Alternativă: Șterge prin WordPress CLI API
            # Pentru moment: Raportează și cere manual cleanup
            self.log(f"   ⚠️ Phantom ID {product_id} va fi șters manual din phpMyAdmin", "WARNING")
            return False
            
        except Exception as e:
            self.log(f"   ⚠️ Nu am putut șterge phantom ID {product_id}: {e}", "WARNING")
            return False

    def import_to_woocommerce(self, product_data):
        """Importă produs în WooCommerce"""
        try:
            if not self.wc_api:
                # Inițializează API
                self.wc_api = API(
                    url=self.config['WOOCOMMERCE_URL'],
                    consumer_key=self.config['WOOCOMMERCE_CONSUMER_KEY'],
                    consumer_secret=self.config['WOOCOMMERCE_CONSUMER_SECRET'],
                    version="wc/v3",
                    timeout=30
                )
            
            ean = product_data['ean']
            
            # GENEREAZĂ SKU UNIC pentru WooCommerce
            generated_sku = self.generate_unique_sku(ean)
            product_data['sku'] = generated_sku
            
            self.log(f"   🏷️ SKU generat: {generated_sku} (EAN: {ean})", "INFO")
            
            # VERIFICĂ DACĂ PRODUSUL EXISTĂ DEJA (după EAN, nu după SKU)
            self.log(f"   🔍 Verific dacă EAN {ean} există deja în WooCommerce...", "INFO")
            
            existing_product = None
            
            try:
                # Metodă 1: Caută după EAN în meta_data
                search_response = self.wc_api.get("products", params={"search": ean, "per_page": 100})
                
                if search_response.status_code == 200:
                    existing_products = search_response.json()
                    
                    # Filtrează după EAN exact în meta_data
                    for prod in existing_products:
                        for meta in prod.get('meta_data', []):
                            if meta.get('key') == '_ean' and str(meta.get('value')) == str(ean):
                                existing_product = prod
                                break
                        if existing_product:
                            break
                    
                    # Metodă 2: Dacă nu găsim după EAN, verifică dacă SKU-ul generat există
                    if not existing_product:
                        sku_check_response = self.wc_api.get("products", params={"sku": generated_sku})
                        if sku_check_response.status_code == 200:
                            sku_products = sku_check_response.json()
                            if sku_products:
                                existing_product = sku_products[0]
                                self.log(f"   ⚠️ Găsit produs cu SKU {generated_sku} (fără EAN în meta_data)", "WARNING")
                    
                    if existing_product:
                        # Produsul există - ACTUALIZARE
                        product_id = existing_product['id']
                        existing_price = float(existing_product.get('regular_price', 0) or 0)
                        
                        self.log(f"   ⚠️ Produs cu EAN {ean} EXISTĂ deja (ID: {product_id})", "WARNING")
                        self.log(f"   💰 Preț curent în WooCommerce: {existing_price:.2f} RON", "INFO")
                        
                        # Verifică opțiunea de actualizare
                        if self.update_existing_var.get():
                            self.log(f"   🔄 MODE: ACTUALIZARE (update_existing = ON)", "INFO")
                            return self.update_product(product_id, product_data)
                        else:
                            self.log(f"   ⏭️ MODE: SKIP (update_existing = OFF)", "WARNING")
                            self.log(f"   ⏭️ Sar peste produs - nu se actualizează", "WARNING")
                            return True  # Considerăm ca "succes" pentru a nu afișa ca eroare
            except Exception as check_error:
                self.log(f"   ⚠️ Nu am putut verifica duplicatele: {check_error}", "WARNING")
                # Continuăm cu crearea
            
            # CREEAZĂ PRODUS NOU
            # Convertește preț EUR → RON
            price = product_data['price']
            if self.convert_price_var.get():
                exchange_rate = float(self.exchange_rate_var.get())
                price = price * exchange_rate
            
            # Pregătește datele pentru WooCommerce
            wc_data = {
                'name': product_data['name'],
                'type': 'simple',
                'regular_price': str(round(price, 2)),
                'description': product_data['description'],
                'sku': generated_sku,  # SKU generat automat
                'manage_stock': True,
                'stock_quantity': 10,
                'status': 'publish',
                'meta_data': [
                    {
                        'key': '_ean',
                        'value': ean  # EAN de pe MobileSentrix
                    },
                    {
                        'key': '_supplier_ean',
                        'value': ean  # Backup pentru identificare furnizor
                    }
                ]
            }
            
            # Upload imagini dacă există
            if product_data.get('images'):
                wc_data['images'] = product_data['images']
            
            self.log(f"   📤 Creez produs nou în WooCommerce (SKU: {generated_sku})...", "INFO")
            self.log(f"   📝 Date produs: Nume={wc_data['name']}, Preț={wc_data['regular_price']} RON, EAN={ean}", "INFO")
            
            # Creează produs cu mecanism ROBUST de retry și phantom cleanup
            max_retries = 5
            retry_count = 0
            phantom_ids_created = []
            
            while retry_count < max_retries:
                self.log(f"   📡 Trimit cerere POST /products (încercare {retry_count + 1}/{max_retries})...", "INFO")
                response = self.wc_api.post("products", wc_data)
                self.log(f"   📥 Răspuns primit: Status {response.status_code}", "INFO")
                
                # SUCCES - Produs creat
                if response.status_code == 201:
                    product_id = response.json()['id']
                    product_sku = response.json().get('sku', 'N/A')
                    self.log(f"   ✓ Status 201 - Produs creat! ID={product_id}, SKU={product_sku}", "SUCCESS")
                    
                    # VERIFICARE POST-CREARE: Confirmă că e complet (nu phantom)
                    try:
                        self.log(f"   🔍 Verific că produs e complet (GET)...", "INFO")
                        verify_response = self.wc_api.get(f"products/{product_id}")
                        
                        if verify_response.status_code == 200:
                            verified_product = verify_response.json()
                            verified_sku = verified_product.get('sku', 'N/A')
                            verified_status = verified_product.get('status', 'N/A')
                            
                            self.log(f"   ✓ Produs verificat complet: ID={product_id}, SKU={verified_sku}, Status={verified_status}", "SUCCESS")
                            self.log(f"   ✅ PRODUS CREAT ȘI SALVAT COMPLET (NU PHANTOM)!", "SUCCESS")
                            return True
                        else:
                            self.log(f"   ⚠️ Verificare eșuată ({verify_response.status_code}) - posibil phantom", "WARNING")
                            # Încercă ștergere
                            try:
                                self.wc_api.delete(f"products/{product_id}", params={"force": True})
                                self.log(f"   🗑️ Ștergere phantom ID {product_id}", "INFO")
                            except:
                                pass
                            return False
                            
                    except Exception as ver_err:
                        self.log(f"   ⚠️ Nu pot verifica produsul: {ver_err}", "WARNING")
                        return True  # Considerăm succes dacă am primit 201
                
                # CONFLICT - Duplicate entry OU EROARE 400 GENERICĂ
                elif response.status_code == 400:
                    decoded_text = html.unescape(response.text)
                    
                    # Extrage mesajul de eroare pentru logging
                    try:
                        error_json = response.json()
                        error_msg = error_json.get('message', decoded_text[:200])
                    except:
                        error_msg = decoded_text[:200]
                    
                    self.log(f"   ⚠️ Status 400 - {error_msg}", "WARNING")
                    
                    # Verific dacă este eroare de "Duplicate entry"
                    if "Duplicate entry" in decoded_text:
                        retry_count += 1
                        self.log(f"   ⚠️ Conflict detectat (încercare {retry_count}/{max_retries})", "WARNING")
                        
                        # Extrage phantom ID
                        match = re.search(r"Duplicate entry '(\d+)' for key 'PRIMARY'", decoded_text)
                        
                        if match:
                            phantom_id = match.group(1)
                            phantom_ids_created.append(phantom_id)
                            self.log(f"   🔍 Phantom ID creat: {phantom_id}", "WARNING")
                            
                            # ⭐ Încearcă ștergere automată a phantom ID-ului
                            delete_success = False
                            try:
                                self.log(f"   🗑️ Încerc ștergere AUTOMATĂ phantom ID {phantom_id} via API...", "INFO")
                                delete_response = self.wc_api.delete(f"products/{phantom_id}", params={"force": True})
                                
                                if delete_response.status_code in [200, 204]:
                                    self.log(f"   ✅ Phantom ID {phantom_id} șters cu succes via API! Retry importul...", "SUCCESS")
                                    phantom_ids_created.remove(phantom_id)
                                    time.sleep(0.5)
                                    delete_success = True
                                    continue  # Reîncearcă IMEDIAT cu aceeași SKU
                                else:
                                    self.log(f"   ⚠️ API Delete eșuat (status {delete_response.status_code}) - phantom e incomplet", "WARNING")
                            except Exception as del_err:
                                self.log(f"   ⚠️ Eroare API DELETE: {del_err}", "WARNING")
                            
                            # Dacă ștergere API a eșuat, încearcă ștergere directă din baza de date
                            if not delete_success:
                                self.log(f"   🔧 Încerc ștergere directă din baza de date (MySQL)...", "INFO")
                                try:
                                    # Mesaj informativ cu SQL-ul necesar (nu avem mysql-connector disponibil)
                                    self.log(f"   💡 Pentru ștergere manuală din phpMyAdmin:", "INFO")
                                    self.log(f"      DELETE FROM wplt_posts WHERE ID={phantom_id};", "INFO")
                                    self.log(f"      DELETE FROM wplt_postmeta WHERE post_id={phantom_id};", "INFO")
                                    self.log(f"      DELETE FROM wplt_wc_product_meta_lookup WHERE product_id={phantom_id};", "INFO")
                                    
                                except Exception as db_err:
                                    self.log(f"   ⚠️ Nu am putut afișa instrucțiuni MySQL: {db_err}", "WARNING")
                        
                        # Generează SKU COMPLET UNIC pentru retry (trebuie să ocolim phantom ID)
                        unique_suffix = f"{str(uuid.uuid4())[:8]}-{int(time.time() * 1000) % 10000}"
                        new_sku = f"WEBGSM-{ean[-6:]}-{unique_suffix}"
                        wc_data['sku'] = new_sku
                        
                        self.log(f"   🆕 Retry cu SKU UNIC (evităm phantom): {new_sku}", "INFO")
                        time.sleep(0.5)
                        continue
                    else:
                        # Eroare 400 dar NU este "Duplicate entry" - posibil date invalide
                        retry_count += 1
                        self.log(f"   ⚠️ Eroare validare date (încercare {retry_count}/{max_retries})", "WARNING")
                        
                        # Reîncearcă cu UUID (poate nu era SKU-ul problema)
                        unique_suffix = f"{str(uuid.uuid4())[:8]}-{int(time.time() * 1000) % 10000}"
                        new_sku = f"WEBGSM-{ean[-6:]}-{unique_suffix}"
                        wc_data['sku'] = new_sku
                        
                        self.log(f"   🔄 Reîncerc cu alt SKU și validez datele...", "INFO")
                        time.sleep(0.5)
                        continue
                    
                
                # ALTĂ EROARE
                else:
                    self.log(f"   ✗ Eroare neașteptată: Status {response.status_code}", "ERROR")
                    if retry_count < max_retries:
                        retry_count += 1
                        unique_suffix = f"{str(uuid.uuid4())[:8]}-{int(time.time() * 1000) % 10000}"
                        new_sku = f"WEBGSM-{ean[-6:]}-{unique_suffix}"
                        wc_data['sku'] = new_sku
                        self.log(f"   🔄 Reîncerc cu alt SKU...", "INFO")
                        time.sleep(1)
                        continue
                    else:
                        break
            
            # EȘEC FINAL
            self.log(f"   ✗ EȘEC FINAL după {max_retries} încercări", "ERROR")
            
            if phantom_ids_created:
                self.log(f"   🔴 Phantom IDs create: {phantom_ids_created}", "ERROR")
                self.log(f"   💡 SOLUȚIE:", "INFO")
                self.log(f"       1. Deschide phpMyAdmin", "INFO")
                self.log(f"       2. Rulează: CLEANUP_COPY_PASTE.txt", "INFO")
                self.log(f"       3. Resetează AUTO_INCREMENT la 1", "INFO")
                self.log(f"       4. Relansează importul", "INFO")
            
            return False
                
        except Exception as e:
            self.log(f"   ✗ Eroare import WooCommerce: {e}", "ERROR")
            import traceback
            self.log(f"   📝 Traceback: {traceback.format_exc()}", "ERROR")
            return False
    
    def update_product(self, product_id, product_data):
        """Actualizează un produs existent în WooCommerce cu tracking de preț"""
        try:
            ean = product_data.get('ean', 'N/A')
            
            # Convertește preț EUR → RON
            price_new = product_data['price']
            if self.convert_price_var.get():
                exchange_rate = float(self.exchange_rate_var.get())
                price_new = price_new * exchange_rate
            
            price_new_str = str(round(price_new, 2))
            
            # 1. PRELUĂ PREȚUL VECHI din baza de date
            self.log(f"   🔍 Preluez prețul curent din WooCommerce...", "INFO")
            try:
                get_response = self.wc_api.get(f"products/{product_id}")
                if get_response.status_code == 200:
                    existing_product = get_response.json()
                    price_old = float(existing_product.get('regular_price', 0) or 0)
                    
                    self.log(f"   💰 PREȚ VECHI: {price_old:.2f} RON", "INFO")
                    self.log(f"   💰 PREȚ NOU:  {price_new_str} RON", "INFO")
                    
                    # Calculează diferență
                    if price_old > 0:
                        price_diff = price_new - price_old
                        price_pct = (price_diff / price_old) * 100
                        if price_diff > 0:
                            self.log(f"   📈 CREȘTERE:  +{price_diff:.2f} RON (+{price_pct:.1f}%)", "SUCCESS")
                        elif price_diff < 0:
                            self.log(f"   📉 SCĂDERE:   {price_diff:.2f} RON ({price_pct:.1f}%)", "SUCCESS")
                        else:
                            self.log(f"   🔄 PREȚ NESCHIMBAT (identic)", "INFO")
                    else:
                        self.log(f"   📊 Preț inițial: 0 RON → {price_new_str} RON", "INFO")
                else:
                    price_old = None
                    self.log(f"   ⚠️ Nu s-a putut prelua prețul vechi", "WARNING")
            except Exception as get_error:
                price_old = None
                self.log(f"   ⚠️ Eroare preluare preț: {get_error}", "WARNING")
            
            # 2. PREGĂTESC DATELE PENTRU ACTUALIZARE
            self.log(f"   📤 Trimit cerere PUT /products/{product_id}...", "INFO")
            
            wc_data = {
                'name': product_data['name'],
                'regular_price': price_new_str,
                'description': product_data['description'],
                'stock_quantity': 10,
                'status': 'publish'
            }
            
            # Upload imagini dacă există
            if product_data.get('images'):
                wc_data['images'] = product_data['images']
            
            # 3. ACTUALIZEAZĂ PRODUS
            response = self.wc_api.put(f"products/{product_id}", wc_data)
            
            if response.status_code == 200:
                self.log(f"   ✓ Răspuns WooCommerce: Status 200 (Updated)", "SUCCESS")
                
                # 4. VERIFICARE POST-ACTUALIZARE: Confirmă că prețul s-a salvat
                self.log(f"   🔍 Verificare post-actualizare (GET /products/{product_id})...", "INFO")
                try:
                    verify_response = self.wc_api.get(f"products/{product_id}")
                    if verify_response.status_code == 200:
                        verified_product = verify_response.json()
                        verified_price = float(verified_product.get('regular_price', 0) or 0)
                        verified_name = verified_product.get('name', 'N/A')
                        
                        # Verifică că prețul s-a salvat corect
                        if abs(verified_price - price_new) < 0.01:  # tolerance 0.01 RON
                            self.log(f"   ✓ Prețul verificat în DB: {verified_price:.2f} RON", "SUCCESS")
                            self.log(f"   ✓ PRODUS ACTUALIZAT ȘI VERIFICAT!", "SUCCESS")
                            self.log(f"   📋 EAN: {ean} | Nume: {verified_name}", "INFO")
                            return True
                        else:
                            self.log(f"   ⚠️ AVERTISMENT: Preț salvat ({verified_price:.2f}) ≠ Preț trimes ({price_new_str})", "WARNING")
                            return True  # Considerăm parțial succes
                    else:
                        self.log(f"   ⚠️ Produs actualizat dar verificare eșuată ({verify_response.status_code})", "WARNING")
                        return True
                except Exception as verify_error:
                    self.log(f"   ⚠️ Nu am putut verifica după actualizare: {verify_error}", "WARNING")
                    return True
            else:
                self.log(f"   ✗ Eroare actualizare: Status {response.status_code}", "ERROR")
                try:
                    error_data = response.json()
                    if 'message' in error_data:
                        self.log(f"   📝 Mesaj: {error_data['message']}", "ERROR")
                except:
                    self.log(f"   📝 Răspuns: {response.text[:300]}", "ERROR")
                return False
                
        except Exception as e:
            self.log(f"   ✗ Eroare actualizare: {e}", "ERROR")
            return False

# Main
if __name__ == "__main__":
    root = tk.Tk()
    app = ImportProduse(root)
    root.mainloop()
